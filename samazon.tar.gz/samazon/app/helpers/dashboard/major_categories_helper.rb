module Dashboard::MajorCategoriesHelper
end
