class Follow < Socialization::ActiveRecordStores::Follow
end
