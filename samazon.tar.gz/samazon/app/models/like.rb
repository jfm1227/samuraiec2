class Like < Socialization::ActiveRecordStores::Like
end
