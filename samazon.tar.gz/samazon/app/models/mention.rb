class Mention < Socialization::ActiveRecordStores::Mention
end
