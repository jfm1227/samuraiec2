require 'test_helper'

class Dashboard::MajorCategoriesControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
