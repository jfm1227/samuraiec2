require 'test_helper'

class MajorCategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
